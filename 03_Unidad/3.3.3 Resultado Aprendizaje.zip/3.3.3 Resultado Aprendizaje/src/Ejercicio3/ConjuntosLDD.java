package Ejercicio3;

import lista.DLinkedList;

public class ConjuntosLDD extends DLinkedList {

}
