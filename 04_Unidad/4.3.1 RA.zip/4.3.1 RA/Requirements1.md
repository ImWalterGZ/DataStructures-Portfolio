Using the Stack class created with double lists, do the following:
Exercise 1:
In a stable, a herd of hippos is kept. The hippos need to be arranged according to their weight, using two additional stables. The stables are so narrow that the hippos must be lined up in a row (stack). Each stable has an opening that serves as both entrance and exit. Show the original stack and the stack of hippos sorted by weight from highest to lowest.
Note: the user must input the original stack with the weights of the hippos (10 hippos)
